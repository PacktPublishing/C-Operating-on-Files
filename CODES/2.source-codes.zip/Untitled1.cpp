// TOPIC: STREAM
// PUT IN from a keyboard - source (entrance)
// PUT OUT to the file - destination (exit)

#include <iostream>

using namespace std;

int main()
{
    int a;

    cin >> a;

    cout << a;
    return 0;
}
